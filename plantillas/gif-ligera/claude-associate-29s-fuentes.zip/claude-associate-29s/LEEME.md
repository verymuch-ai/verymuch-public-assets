# Claude Certified Associate — fuente editable de la versión de 29 segundos

Esta es la última composición entregada: CTA «Comenta aquí abajo», texto por bloques, «Sin programar» verde, badge giratorio, mascota original y pulso de iluminación del cartel.

## Abrir y editar

Abre `site/associate-linkedin-29s.html` en un navegador. Incluye los recursos locales en `site/assets/` y los tres runtimes JS. La copia HTML independiente entregada junto al ZIP integra todo en un solo archivo y también funciona sin conexión.

Para Opus: el marcado de las cuatro tarjetas está en `copy-slide`; el diseño, en los estilos de `.cert-header`, `.interactive-tv`, `.copy-slide` y `.sign`; la cronología activa empieza en `const DURATION=29`, cerca del final. El motor anterior de Fábrica permanece incluido, con lógica sobrescrita al final: los textos/props antiguos del motor NO son el guion actual. No es una nueva familia registrada en GitHub ni un componente genérico ya parametrizado.

La escena usa un lienzo maestro de 1080 × 1350. GIF de referencia: 720 × 900, 29 segundos, 236 fotogramas y 3.127.966 bytes. Entrada de pantallas: 0,85; 8,8; 15,5; 22 segundos. El manifiesto JSON conserva la captura variable exacta. El HTML se reproduce a la frecuencia del navegador; esa frecuencia no representa la del GIF.

## Captura determinista

`window.__dcReady` espera la preparación; `window.__duration` devuelve 29; `window.__seek(t)` fija un instante. Usa `?capture=1` para desactivar la reproducción de la vista previa, o llama a `window.__pause()` antes de capturar. `window.__play()` reanuda la vista previa.

Para reproducir la exportación, requiere Node, Python 3, ffmpeg y Chrome headless. Instala dependencias con `npm ci`, configura `CHROME_HEADLESS_PATH` con tu ejecutable y ejecuta:

```sh
node capture-linkedin-29s.mjs --render
ffmpeg -y -framerate 15 -i frames-linkedin-29s/%04d.png -i cta-comenta-palette.png -filter_complex '[0:v]scale=720:900:flags=lanczos[v];[v][1:v]paletteuse=dither=none:diff_mode=rectangle[out]' -map '[out]' -loop 0 linkedin-29s-unretimed.gif
python3 retime-linkedin-29s.py
```

`reexportado.gif` restaura los tiempos del manifiesto; el GIF intermedio NO tiene la duración correcta. Si cambian contenido, colores o duración, habrá que recalcular paleta y captura. La paleta suministrada reserva colores del logo original; no sustituirla por una reducción automática agresiva.

## Entrega a Opus

Trabajar a partir de esta escena aprobada. Mantener logos y mascota originales. Antes de convertirla en familia reutilizable, separar el contenido, la cronología y los recursos del código heredado de Fábrica. Los presupuestos propuestos de menos de 30 segundos, hasta 240 fotogramas y menos de 5 MB son objetivos internos conservadores, no una afirmación de un máximo oficial universal de duración de LinkedIn.
