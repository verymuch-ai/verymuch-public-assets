import puppeteer from 'puppeteer-core';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)), site=path.join(root,'site');
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.woff2':'font/woff2'};
const server=createServer(async(req,res)=>{try{const rel=decodeURIComponent(new URL(req.url,'http://localhost').pathname);const p=path.join(site,rel);const data=await readFile(p);res.writeHead(200,{'Content-Type':types[path.extname(p)]||'application/octet-stream'});res.end(data)}catch{res.writeHead(404);res.end()}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;
const browser=await puppeteer.launch({executablePath:process.env.CHROME_HEADLESS_PATH||path.resolve(root,'../claude-gif/node_modules/.remotion/chrome-headless-shell/mac-arm64/chrome-headless-shell-mac-arm64/chrome-headless-shell'),headless:true,args:['--no-sandbox','--hide-scrollbars']});
try{
 const page=await browser.newPage();
 page.on('response',r=>{if(r.status()===404)console.error('MISSING',r.url())});
 page.on('pageerror',e=>console.error('PAGEERROR:',e.message));
 page.on('console',m=>{if(m.type()==='warning'||m.type()==='error')console.error(m.text())});
 await page.setViewport({width:936,height:601,deviceScaleFactor:1});
 await page.setViewport({width:1080,height:1350,deviceScaleFactor:1});
 await page.goto(origin+'/associate-linkedin-29s.html?capture=1',{waitUntil:'networkidle0'});
 await page.waitForFunction(()=>typeof window.__seek==='function');
 await page.evaluate(()=>window.__dcReady);
 await page.evaluate(()=>document.fonts.ready);
 const info=await page.evaluate(()=>({duration:window.__duration,loadedBadge:!!document.querySelector('.badge-front')?.naturalWidth,sourceTiming:window.__factoryInstance.tm,footerBottom:document.querySelector('.brand-footer').getBoundingClientRect().bottom,console:document.querySelector('#vm-fabrica-consola').getBoundingClientRect().toJSON(),fonts:[document.fonts.check('700 20px "Schibsted Grotesk"'),document.fonts.check('400 20px "Geist Mono"'),document.fonts.check('400 20px "Anthropic Serif"')]}));
 await writeFile(path.join(root,'linkedin-29s-render-info.json'),JSON.stringify(info,null,2));console.log(JSON.stringify(info));
 const seek=async t=>{await page.evaluate(async t=>{window.__seek(t);await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));window.__seek(t);await new Promise(resolve=>requestAnimationFrame(resolve))},t)};
 if(process.argv.includes('--render')){
  const frames=path.join(root,'frames-linkedin-29s');await mkdir(frames,{recursive:true});
  const segments=[[0,4.1,14],[4.1,8.4,6],[8.4,9.9,12],[9.9,15.1,6],[15.1,16.6,12],[16.6,21.6,6],[21.6,23.1,12],[23.1,29,6]];
  const cs=new Set([0]);for(const [a,b,fps] of segments){for(let n=0;a+n/fps<b-1e-8;n++)cs.add(Math.round((a+n/fps)*100));}
  const times=[...cs].sort((a,b)=>a-b),count=times.length;
  if(count>250)throw new Error('Frame budget exceeded: '+count);
  await writeFile(path.join(root,'linkedin-29s-timing.json'),JSON.stringify({durationCs:2900,timesCs:times},null,2));
  for(let i=0;i<count;i++){await seek(times[i]/100);await page.screenshot({path:path.join(frames,String(i).padStart(4,'0')+'.png')});if(i%40===0)console.log('Frame',i,'/',count)}

 }else{
  for(const [name,t] of [['badge-intro',1],['badge-reveal',16.45],['badge-first',11],['badge-second',27],['badge-third',38],['badge-fourth',48],['badge-cta',6.5],['badge-return',53]]){await seek(t);await page.screenshot({path:path.join(root,name+'.png')})}
 }
}finally{await browser.close();server.close()}
