from pathlib import Path
import struct,json
root=Path(__file__).resolve().parent
src=root/'linkedin-29s-unretimed.gif'
out=root/'reexportado.gif'
timing=json.loads((root/'linkedin-29s-timing.json').read_text())
b=bytearray(src.read_bytes());assert b[:6] in [b'GIF89a',b'GIF87a']
i=13+(3*(2**((b[10]&7)+1)) if b[10]&128 else 0);delays=[];frames=0

def skip_blocks(i):
 while b[i]:i+=1+b[i]
 return i+1

while i<len(b):
 tag=b[i]
 if tag==0x3b:break
 if tag==0x21:
  if b[i+1]==0xf9:
   assert b[i+2]==4;delays.append(i+4)
  i=skip_blocks(i+2)
 elif tag==0x2c:
  packed=b[i+9];i+=10
  if packed&128:i+=3*(2**((packed&7)+1))
  i=skip_blocks(i+1);frames+=1
 else:raise ValueError((i,tag))
times=timing['timesCs']+[timing['durationCs']]
assert len(delays)==frames==len(times)-1,(len(delays),frames,len(times)-1)
for k,p in enumerate(delays):
 delay=times[k+1]-times[k];assert delay>=2;struct.pack_into('<H',b,p,delay)
assert sum(struct.unpack_from('<H',b,p)[0] for p in delays)==2900
out.write_bytes(b)
print(json.dumps({'file':str(out),'frames':frames,'duration':29,'bytes':len(b),'longHoldsSeconds':[round((times[k+1]-times[k])/100,2) for k in range(frames) if times[k+1]-times[k]>50]}))
